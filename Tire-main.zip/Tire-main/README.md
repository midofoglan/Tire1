## About Tire

I developed A Customer Relationship Management using very up-to-date technology. the site
can connect the car's owner with mechanics based on the distance between them and their rate.
also, the customer can add his car and all his visits will be recorded in the Database.


Technologies:
- Laravel (breeze) 
- TailwindCSS 
- Spite/laravel 
- Multiple Auth
- Dark mode
- store user location
